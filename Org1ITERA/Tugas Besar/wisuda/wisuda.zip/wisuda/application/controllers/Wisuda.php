<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wisuda extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->library('session');
	}
	public function index()
	{	$data['nama']="Guest";
		$data['logged_in']=0;
		$this->session->set_userdata($data);
	
		$this->load->view('Template',$data);
		
	}
	public function dashboard(){
		$check = $this->session->userdata('logged_in');
		if($check==0){
			$data['nama']="Guest";
			$this->load->view('Template',$data);
		}
		else{
			$type = $this->session->userdata('type');
			if($type=="mhs"){
				$data['nama']=$this->session->userdata('nama');
				$this->load->view('Template',$data);
			}
			else{

			}
			
		}
	}
	public function profile(){
		$check = $this->session->userdata('logged_in');
		if($check==1){
			if($this->session->userdata('type')=="mhs"){
				$data['nama']=$this->session->userdata('nama');
				$data['nim']=$this->session->userdata('nim');
				$data['jenis_kelamin']=$this->session->userdata('jenis_kelamin');
				$data['alamat']=$this->session->userdata('alamat');
				$data['foto']=$this->session->userdata('foto');
				$data['sidangta_1']=$this->session->userdata('sidangta_1');
				$data['sidangta_2']=$this->session->userdata('sidangta_2');
				$data['kkn']=$this->session->userdata('kkn');
				$data['kp']=$this->session->userdata('kp');
				$this->beranda($data);

			}
		}
		else if($check==0){
				$this->load->view('Login');
			}
	
	}
	public function daftar(){
		$check = $this->session->userdata('logged_in');
		if($check==1){
			if($this->session->userdata('type')=="mhs"){
				$data['nama']=$this->session->userdata('nama');
				$data['nim']=$this->session->userdata('nim');
				$data['jenis_kelamin']=$this->session->userdata('jenis_kelamin');
				$data['alamat']=$this->session->userdata('alamat');
				$data['foto']=$this->session->userdata('foto');
				$data['sidangta_1']=$this->session->userdata('sidangta_1');
				$data['sidangta_2']=$this->session->userdata('sidangta_2');
				$data['kkn']=$this->session->userdata('kkn');
				$data['kp']=$this->session->userdata('kp');
				$this->load->view('Daftarwisuda',$data);

			}
		}
		else if($check==0){
				$this->load->view('Login');
			}
	}
	public function page_login(){
		
		$check = $this->session->userdata('logged_in');
		if($check==1){
			if($this->session->userdata('type')=="mhs"){
				$data['nama']=$this->session->userdata('nama');
				$data['nim']=$this->session->userdata('nim');
				$data['jenis_kelamin']=$this->session->userdata('jenis_kelamin');
				$data['alamat']=$this->session->userdata('alamat');
				$data['foto']=$this->session->userdata('foto');
				$data['sidangta_1']=$this->session->userdata('sidangta_1');
				$data['sidangta_2']=$this->session->userdata('sidangta_2');
				$data['kp']=$this->session->userdata('kp');
				$this->beranda($data);

			}
		}
		else if($check==0){
				$this->load->view('Login');
			}
	}
	public function beranda($data){
		$this->load->view('Afterlogin',$data);
	}
	public function Login(){
		extract($_POST);
		$this->load->model('Site_model');
		$query = $this->Site_model->getDataUser($_POST['Username'])->result_array();
		if($query==NULL){
			
		}
		else{
			foreach ($query as $key => $value) {
				# code...
				$user_login=array(
					'username' =>$value['username'],
					'password' =>$value['password'],
					'type' =>$value['type'],
					'logged_in' =>1
					);
				$this->session->set_userdata($user_login);
			}
			if($user_login['username']!=$_POST['Username']||$user_login['password']!=$_POST['Password']){
				$this->load->view('Loginerror');
			}
			else{
				if($user_login['type']=="mhs"){
					$query2 = $this->Site_model->getDataMhs($user_login['username'])->result_array();
					foreach ($query2 as $key => $data) {
						# code...
						$mhs_login=array(
							'nim'=>$data['nim'],
							'nama'=>$data['nama'],
							'jenis_kelamin'=>$data['jenis_kelamin'],
							'telp'=>$data['telp'],
							'alamat' =>$data['alamat'],
							'foto'=>$data['foto'],
							'sidangta_1'=>$data['sidangta_1'],
							'sidangta_2'=>$data['sidangta_2'],
							'kkn'=>$data['kkn']
							);
						$this->session->set_userdata($mhs_login);
					}
					$this->beranda($data);
				}
				else{
					redirect('Template');
				}
			}
		}
		
	}
	public function logout(){
		$this->session->sess_destroy();
		$this->index();
	}

}
