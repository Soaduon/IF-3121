<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site_model extends CI_Model {
public function __construct()
    {
        parent::__construct();
    }
	public function getDataUser($username){
		return $data = $this->db->select("*")
		->from("tbl_user")
		->where("tbl_user.username=",$username)
		->get();
	}
	public function getDataMhs($username){
		return $data = $this->db->select("*")
		->from("tbl_mhs")
		->where("tbl_mhs.username=",$username)
		->get();
	}
}